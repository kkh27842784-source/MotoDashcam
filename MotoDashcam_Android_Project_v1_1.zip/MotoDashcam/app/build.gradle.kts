plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "kr.motodashcam"
    compileSdk = 35
    defaultConfig { applicationId = "kr.motodashcam"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-video:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    // Kakao Mobility in-app navigation SDK (safe-driving mode; requires app registration/key)
    implementation("com.kakaomobility.knsdk:knsdk_ui:1.12.8")
}
