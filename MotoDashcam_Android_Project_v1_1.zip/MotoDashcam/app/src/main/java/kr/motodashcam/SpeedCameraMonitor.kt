package kr.motodashcam

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

/** GPS-based speed-camera alerts. Camera data is loaded from filesDir/speed_cameras.csv.
 * CSV columns: latitude,longitude,speed_limit_kmh,name (header optional).
 */
class SpeedCameraMonitor(private val context: Context) : LocationListener {
    data class Camera(val lat: Double, val lon: Double, val limit: Int, val name: String)
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var cameras: List<Camera> = emptyList()
    private var lastAlertCamera = -1
    private var lastAlertAt = 0L

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.KOREAN
            }
        }
        loadCameras()
    }

    fun start() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 5f, this)
        } catch (_: Exception) { }
    }

    fun stop() {
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
    }

    private fun loadCameras() {
        val file = File(context.filesDir, "speed_cameras.csv")
        if (!file.exists()) {
            file.writeText("latitude,longitude,speed_limit_kmh,name\n", Charsets.UTF_8)
        }
        cameras = file.readLines(Charsets.UTF_8).mapNotNull { line ->
            val p = line.split(',').map { it.trim() }
            if (p.size < 3) return@mapNotNull null
            val lat = p[0].toDoubleOrNull() ?: return@mapNotNull null
            val lon = p[1].toDoubleOrNull() ?: return@mapNotNull null
            val limit = p[2].toDoubleOrNull()?.roundToInt() ?: return@mapNotNull null
            if (lat !in -90.0..90.0 || lon !in -180.0..180.0 || limit !in 10..160) return@mapNotNull null
            Camera(lat, lon, limit, p.getOrElse(3) { "과속 단속 카메라" })
        }
    }

    fun reloadCameras() = loadCameras()

    override fun onLocationChanged(location: Location) {
        if (cameras.isEmpty()) return
        val speedKmh = if (location.hasSpeed()) (location.speed * 3.6f).roundToInt() else 0
        var nearestIndex = -1
        var nearestDistance = Float.MAX_VALUE
        cameras.forEachIndexed { index, camera ->
            val target = Location("speed-camera").apply { latitude = camera.lat; longitude = camera.lon }
            val distance = location.distanceTo(target)
            if (distance < nearestDistance) { nearestDistance = distance; nearestIndex = index }
        }
        if (nearestIndex < 0) return
        val camera = cameras[nearestIndex]
        val now = System.currentTimeMillis()
        if (nearestDistance <= 500f && (nearestIndex != lastAlertCamera || now - lastAlertAt > 45_000L)) {
            val message = if (speedKmh > camera.limit) {
                "주의, 전방 ${camera.name}. 제한속도 ${camera.limit}, 현재 속도 약 ${speedKmh}. 감속하세요."
            } else {
                "전방 ${camera.name}. 제한속도 ${camera.limit}. 안전 운전하세요."
            }
            if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "camera_$nearestIndex")
            lastAlertCamera = nearestIndex
            lastAlertAt = now
        }
        if (nearestDistance > 1000f) lastAlertCamera = -1
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
}
