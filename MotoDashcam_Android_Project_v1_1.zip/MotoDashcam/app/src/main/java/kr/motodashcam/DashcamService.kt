package kr.motodashcam

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor

class DashcamService : LifecycleService() {
    companion object { const val ACTION_START = "kr.motodashcam.START"; const val ACTION_STOP = "kr.motodashcam.STOP"; const val ACTION_RELOAD_CAMERAS = "kr.motodashcam.RELOAD_CAMERAS"; private const val CHANNEL = "dashcam_recording"; private const val NOTIF = 41 }
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var speedCameraMonitor: SpeedCameraMonitor? = null
    private var stopping = false
    private var rollover = false
    private val mainExecutor: Executor by lazy { androidx.core.content.ContextCompat.getMainExecutor(this) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var rolloverTask: Runnable? = null

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) { ACTION_STOP -> stopCapture(); ACTION_RELOAD_CAMERAS -> speedCameraMonitor?.reloadCameras(); else -> { startForeground(NOTIF, notification("카메라 연결 중…")); startSpeedCameraMonitor(); startCamera() } }
        return START_NOT_STICKY
    }
    private fun startSpeedCameraMonitor() {
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (speedCameraMonitor == null) speedCameraMonitor = SpeedCameraMonitor(this)
            speedCameraMonitor?.start()
        }
    }
    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.SD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, videoCapture)
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MotoDashcam:Recording").apply { acquire() }
                stopping = false; rollover = false; startSegment()
            } catch (e: Exception) { updateNotification("카메라 시작 실패: 권한·다른 카메라 앱 확인"); stopSelf() }
        }, mainExecutor)
    }
    private fun startSegment() {
        if (stopping) return
        val capture = videoCapture ?: return
        val dir = File(getExternalFilesDir(null), "MotoDashcam").apply { mkdirs() }
        prune(dir)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(Date())
        val file = File(dir, "ride_$stamp.mp4")
        var pending: PendingRecording = capture.output.prepareRecording(this, FileOutputOptions.Builder(file).build())
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(mainExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start -> updateNotification("녹화 중 · 3분 단위 저장")
                is VideoRecordEvent.Finalize -> {
                    rolloverTask?.let { handler.removeCallbacks(it) }
                    rolloverTask = null
                    recording = null
                    if (!stopping && !event.hasError()) startSegment()
                    else if (stopping) { releaseWakeLock(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                    else { updateNotification("저장 오류 · 녹화 재시작 중"); startSegment() }
                }
            }
        }
        // Segment rollover after approximately three minutes.
        rolloverTask?.let { handler.removeCallbacks(it) }
        val thisRecording = recording
        val task = Runnable { if (!stopping && recording === thisRecording) { rollover = true; thisRecording?.stop() } }
        rolloverTask = task
        handler.postDelayed(task, 180_000L)
    }
    private fun prune(dir: File) {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".mp4") && !f.name.startsWith("LOCKED_") }?.sortedBy { it.lastModified() }?.toMutableList() ?: return
        var total = files.sumOf { it.length() }
        val maxBytes = 2L * 1024 * 1024 * 1024
        for (f in files) { if (total <= maxBytes) break; val len = f.length(); if (f.delete()) total -= len }
    }
    private fun stopCapture() { stopping = true; rolloverTask?.let { handler.removeCallbacks(it) }; rolloverTask = null; recording?.stop() ?: run { releaseWakeLock(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() } }
    private fun releaseWakeLock() { try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}; wakeLock = null }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val ch = NotificationChannel(CHANNEL, "블랙박스 녹화", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(ch) } }
    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, DashcamService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("모토 블랙박스").setContentText(message).setContentIntent(open).addAction(0, "녹화 종료", stop).setOngoing(true).build()
    }
    private fun updateNotification(message: String) { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF, notification(message)) }
    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)
    override fun onDestroy() { speedCameraMonitor?.stop(); speedCameraMonitor = null; stopping = true; try { recording?.close() } catch (_: Exception) {}; releaseWakeLock(); super.onDestroy() }
}
