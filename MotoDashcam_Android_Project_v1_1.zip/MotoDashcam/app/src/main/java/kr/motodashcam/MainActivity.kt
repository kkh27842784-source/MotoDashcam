package kr.motodashcam

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.InputStream
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private val req = 101
    private val cameraCsvRequest = 202
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 36, 28, 36); setBackgroundColor(0xFF101010.toInt()) }
        val title = TextView(this).apply { text = "모토 블랙박스"; textSize = 30f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER }
        val desc = TextView(this).apply { text = "오토바이 주행 녹화 · 반복 저장 · 화면 꺼짐 녹화"; textSize = 15f; setTextColor(0xFFBBBBBB.toInt()); gravity = Gravity.CENTER; setPadding(0, 18, 0, 28) }
        status = TextView(this).apply { text = "녹화 대기 중"; textSize = 18f; setTextColor(0xFFFF7043.toInt()); gravity = Gravity.CENTER; setPadding(0, 20, 0, 20) }
        val start = Button(this).apply { text = "녹화 시작"; textSize = 18f; setOnClickListener { requestAndStart() } }
        val stop = Button(this).apply { text = "녹화 종료"; textSize = 18f; setOnClickListener { stopService(Intent(this@MainActivity, DashcamService::class.java)); status.text = "녹화 종료됨" } }
        val saved = Button(this).apply { text = "저장 영상 폴더"; setOnClickListener { val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); startActivity(i) } }
        val cameraData = Button(this).apply { text = "과속 카메라 데이터 가져오기"; setOnClickListener { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/*" }; startActivityForResult(i, cameraCsvRequest) } }
        val cameraInfo = TextView(this).apply { text = "CSV 형식: 위도,경도,제한속도,카메라명\n※ 정확한 카메라 위치 데이터가 있어야 알림이 작동합니다."; textSize = 13f; setTextColor(0xFFBBBBBB.toInt()); gravity = Gravity.CENTER }
        listOf(title, desc, status, start, stop, saved, cameraData, cameraInfo).forEach { v -> root.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 12 }) }
        setContentView(root)
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == cameraCsvRequest && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val target = java.io.File(filesDir, "speed_cameras.csv")
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                status.text = "가져오기 완료 · 다음 녹화 시작 시 적용"
            } catch (_: Exception) { status.text = "CSV 파일을 읽지 못했습니다" }
        }
    }

    private fun requestAndStart() {
        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), req) else startRecording()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == req && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startRecording() else status.text = "카메라·마이크 권한이 필요합니다" }
    private fun startRecording() { ContextCompat.startForegroundService(this, Intent(this, DashcamService::class.java).setAction(DashcamService.ACTION_START)); status.text = "녹화 시작 요청됨 · 알림창에서 상태 확인" }
}
